#ifndef EE_H
#define EE_H


class ee
{
    public:
        ee();
        virtual ~ee();

    protected:

    private:
};

#endif // EE_H
