#include "dok.h"

dok::dok()
{
    //ctor
}

dok::~dok()
{
    //dtor
}
