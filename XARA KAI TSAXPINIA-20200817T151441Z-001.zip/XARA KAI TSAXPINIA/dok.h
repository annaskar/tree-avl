#ifndef DOK_H
#define DOK_H


class dok
{
    public:
        dok();
        virtual ~dok();

    protected:

    private:
};

#endif // DOK_H
