#include "ee.h"

ee::ee()
{
    //ctor
}

ee::~ee()
{
    //dtor
}
