#include "Rational.h"

Rational::Rational()
{
    //ctor
}

Rational::Rational(int par,int ar)
{
   this->par=par;
   this->ar=ar;
}

Rational::~Rational()
{
    //dtor
}
